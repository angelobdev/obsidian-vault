java -cp . is.bbrmi.producer.ProducerClient
