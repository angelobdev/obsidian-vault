CLASSPATH=. rmiregistry
