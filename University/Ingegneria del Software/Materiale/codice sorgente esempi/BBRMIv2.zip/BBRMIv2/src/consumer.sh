java -cp . is.bbrmi.consumer.ConsumerClient
