package is.memento;

public interface Memento {

}
