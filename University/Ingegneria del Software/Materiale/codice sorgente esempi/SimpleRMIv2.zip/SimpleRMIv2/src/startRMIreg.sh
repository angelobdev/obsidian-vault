CLASSPATH=/Users/angelo/IdeaProjects/SimpleRMIv2/out/production/SimpleRMIv2 rmiregistry
