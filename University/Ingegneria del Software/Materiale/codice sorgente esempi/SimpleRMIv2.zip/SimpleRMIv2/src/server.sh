java -cp . is/simpleRMI/server/app/SimpleMsgServer
