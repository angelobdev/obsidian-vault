package is.simpleRMI.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MsgSource extends Remote {
    Message getMessage() throws RemoteException;
}