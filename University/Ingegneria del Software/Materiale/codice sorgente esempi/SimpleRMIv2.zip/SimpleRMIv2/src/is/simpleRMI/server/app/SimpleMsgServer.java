package is.simpleRMI.server.app;

import is.simpleRMI.common.MsgSource;
import is.simpleRMI.server.SimpleMsgSource;
import is.simpleRMI.server.msg.CompoundMessage;
import is.simpleRMI.server.msg.SimpleMessage;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class SimpleMsgServer {
    public static void main(String[] args) {


        try {
            System.out.println("Costruzione oggetto locale ...");
            SimpleMsgSource msgSource = new SimpleMsgSource();
            msgSource.addMessage(new SimpleMessage("Ciao"));

            CompoundMessage cmpMsg = new CompoundMessage();
            cmpMsg.add("come va?");
            cmpMsg.add("come Stai?");

            msgSource.addMessage(cmpMsg);

            msgSource.addMessage(new SimpleMessage("ci vediamo presto"));

            System.out.println("created!");
            MsgSource stub = (MsgSource) UnicastRemoteObject.exportObject(msgSource, 0);
            System.out.println("Pubblicazione msg source ...");
            System.out.flush();

            Naming.rebind("msgSrc", stub);

            System.out.println("In attesa di clienti ...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }// main
}

