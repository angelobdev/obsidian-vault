package is.simpleRMI.common;

public interface Message {
}
