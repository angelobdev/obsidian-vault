package is.simpleRMI.client;

import is.simpleRMI.common.Message;
import is.simpleRMI.common.MsgSource;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.rmi.Naming;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SimpleMsgClient {

    public static void main(String[] args) {
        String ipaddr="localhost";
        if(args.length>0)
            ipaddr=args[0];
        MsgSource remoteObj = null;
        try (Scanner sc = new Scanner(System.in)){

            remoteObj = (MsgSource) Naming.lookup("rmi://"+ipaddr+"/msgSrc");
            for (;;) {
                System.out.print("Press Enter to receive ");
                String answer = sc.nextLine();
                Message msg = remoteObj.getMessage();
                System.out.println("msg=" + msg);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
