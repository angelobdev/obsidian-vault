package is.backtracking.colorazionemappe;

public enum Colore {
	ROSSO, GIALLO, VERDE, BLU;
}
