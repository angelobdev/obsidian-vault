package is.backtracking.nregine;

public class NRegine {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scacchiera sc = new Scacchiera(5, 1000);
		sc.risolvi();
	}

}
